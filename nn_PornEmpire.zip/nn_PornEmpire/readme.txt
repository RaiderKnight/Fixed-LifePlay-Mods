PornEmpire (LifePlay) ReadMe, Change Log and TODO List
========================================================

ReadMe
********

Porn Empire is a LifePlay mod (add-on) that allows you to run your own 
porn business in LifePlay. You start at a very low level taking videos 
with your smart phone of your sex workers and your perverted dates.

Over time your business grows and you can buy more equipment and employ 
workers that will assist you in your daily tasks.

LifePlay version 3.17 or later is required for Porn Empire to work correctly!


Earning money in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Money can be earned by launching a website and putting videos and web cams online. 
Videos will be downloaded by your visitors as soon as you release them and 
they will pay money for that.
* If you have famous models you will get more visitors.
* Model fame grows with an increasing download count.
* If you get better equipment you will get more valuable videos.
* The older a video gets the more its value drops.

Money is currently earned by launching the "Check business performance" 
action in the sex work tab.


Getting videos
~~~~~~~~~~~~~~

Just launch the action "Organize a shooting" from the sex work tab. 
If you have a companion the companion will be asked to take part in the 
session otherwise you can choose one of your contacts.

If the chosen model is not a sex worker or not perverted enough (more than 55%) 
he/she will decline. Try your luck to convince him/her if his/her masochist stat 
is low enough (less than -50%).

Every model will ask for money. You may try to negotiate as well.
If you are really low on money dates and relatives with a good relationship to you 
(rapport more than 55%) may do it without being paid.

By the way, if you convinced someone to become a model the tag "PEModel" 
will be added to this contact.


Uploading stuff
~~~~~~~~~~~~~~~

If you managed to launch your website (action "Launch a porn website" in the 
"Manage business" menu) you can upload previously created videos to it. 

You should do that right after doing some shoots as nobody will be able to see 
your new work if you do not upload it.

A web admin could do that task for you and improve the quality of the uploaded 
content but will cost some money. If you upload stuff it will take your time and 
energy, if you have an admin there will be no time and energy penalty.

Emails and Castings
~~~~~~~~~~~~~~~~~~~

Randomly you can meet someone who wants to model for you. 
If so, invite them for a casting.

To do the casting read your mails. Even if you did not meet 
someone yet it might be, you get some applications by mail.

The more famous you are the more applications you will get.

Models that are added by castings usually are unknown or real 
amateurs so this is a good but cheap chance to get new models.


Porn fame in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~

The porn fame of a model affects the amount of money you earn with him/her. 
Videos of famous models keep the interest in them high for a longer time. 

So a shooting with a famous model costs more money, but the results will be 
better and the demand for them will last longer.

Additionally the models attractiveness affects the value of her/his work. 
... and of course the price ;-)

If a models fame changes after doing a shoot this will also affect the 
value of the footage.

The porn fame of a cam operator and scene assistant affects the quality 
(and therefore price) of the shooting results. A famous CamOp' and scene asist
is also more expensive to hire.


Porn genres in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~~~

There are the following distinct genres in Porn empire: Amateur, Solo, 
Lesbian, Gay, Threesome and Gang Bang / Reverse Gang Bang. 

Your visitors will request all of these genres to be available on your website. 
If you do not satisfy the need you will loose visitors. You should keep at 
least 6 of these 7 genres updated regularly.

How to get these genres? 

 Solo: Have exactly one male or female model do a shooting.
 Gay: Have 1+ male model(s) and no females do a shooting.
 Lesbian: Have 2+ female models do a shooting.
 Threesome: Have 1 male and 2 female or 2 male and 1 female models do a shooting.
 Gang Bang: Have 3 males and 1 female in one shooting.
 Reverse Gang Bang: Have 3 females and 1 male in one shooting.

Amateur requires at least one model of the shooting to have a porn fame 
below 25%. As the fame increases with time (if you uploaded stuff of a model) 
you occasionally have to find new amateurs.

To know what is demanded by your visitors use the 'Manage your business' menu.

To know in which shootings a model did participate use the 'Manage employees' 
menu.

Employees in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~

There are 3 types of employees in PornEmpire:
- Models
- Web cam models
- Regular employees

MODELS 
------

Models don't have contracts with you. 
You book them once, you pay them once.

The model's price depends on fame, intelligence and attractiveness.
The higher these stats are, the more it will cost but it will also perform better.

Porn fame can change later, and will affect previously done shootings.

If you have sex workers ("Offer pimp services") you can ask them to become 
a model as well. They will get a fixed payment and won't be bitchy ;-)

You can ask any contact to be a model, or ask the PornAgency to recruit one - 
or do a casting (by Checking your Mails).

Tag (Contact list): PEModel


WEB CAM MODELS
--------------

Web cam models perform live on web cam. How often, is up to you. 
Contrary to normal models they do have a contract with you. You pay weekly.

Same criteria as for normal models apply for price and results.

Web Cam models can be hired by dating someone, asking a contact or 
sometimes apply for a job themselves. 

Web cam models are likely to also perform as video models.

Tag (Contact list): PEWebCam


CAM OPERATOR
------------

The higher the porn fame of the cam op is, the better the footage will be.
If you hire a cam op with high porn fame you will have to pay a high salary.

You can also hire a newbie and send him/her to trainings to get better.
This will NOT result in increasing salary but in better footage.

A cam op gets better over time. Also they will get aroused during their work 
and like to join after shootings...

A cam operator is required to do shootings with you being one of the actors.

Tag (Contact list): PECamOperator

SCENE ASSISTANT
---------------

The scene assistant is in duty to do the make up, clean up the scene and care 
for all other people at the set.

The higher the porn fame of the assistant is, the better the performance will be.
If you hire an assistant with high porn fame you will have to pay a high salary.

You can also hire a newbie and send him/her to trainings to get better.
This will NOT result in increasing salary but in better footage.

Tag (Contact list): PESceneAssistant


WEB ADMIN
---------

A web admin automatically uploads new footage. The better his/her intelligence is, 
the better his work will be. (Web admins do some magic to increase the value of the 
uploaded stuff. Don't ask - they are nerds and therefore know what other nerds need 
to be attracted... ;-))

If you hire a admin with high intelligence you will have to pay a high salary.

You can also hire a newbie and send him/her to trainings to get better.
This will NOT result in increasing salary but in better footage.

A web admin (if perverted or submissive enough) can be asked to become a model.

Tag (Contact list): PEAdmin


Known problems
~~~~~~~~~~~~~~

If you DELETE a model from your contact list (blocking is OK) you will 
loose all shootings associated to it. This is currently not fixable.

You cannot hire relatives as employees (cam operator, scene assistant, web admin).


Change Log
************

Version 0.7 (07.01.2021):
- REQUIRES LIFEPLAY 3.18 OR LATER!!
- Feature: Added interactions with NPCs - Click them while inside any building (but not home)
    -> Have lewd actions with NPCs that are perverted or submissive enough
    -> Recruit any NPC as model / WebCam model
    -> Recruit any NPC as follower
    -> Film the NPC right in the current location
- Feature: GOD mode added (see PE Settings) 
    -> If enabled, all perversion, masocist etc checks before PE actions are skipped
- Feature: Added emails 
- Feature: Added castings
- Feature: Added random encounters that lead to castings
- Feature: Player can get STD if no condom is used in shootings, interactions or castings (disabled in GOD mode, otherwise 3% chance)
- Modify: Many scenes now use secondScreen feature instead of adding the NPC to the current scene
- Modify: Much old LP 2.x code was removed
     -> Player won't redress anymore in each scene (unless naked)
- Modify: Performance of the busines performance check improved using tagging and clearGetList()
- Modify: Dialog lines (text) for hiring web cam models rewritten
- Modify: Porn fame of Player will increse / decrease with visitor count
- Modify: PE Office reworked. Now has more animation positions and space for them
- Modify: Porn Agency models are now aged 18-35 and some have tatoos
    -> If you want this change to be applied in your existing save use the "nn_pe_debug" function
       to delete and then add all agency models again.
- Modify: Shooting can be done with >= 15 energy and consumes less energy (unless the player joins)
- Fix: Random PE scenes will only trigger in certain sane places
- Fix: Cam models will only ask for a raise if the website is opened
- Fix: Masochist stat <= -50 not read correctly in do_shooting_new (resulting in no shooting with shy but submissive NPC)
- Fix: Can now hire previously hired NPCs again.
- Fix: Porn agency models will now have the correct gender
- Fix: Doing a FMF or MFM scene was not possible if main actor was not bi
- Fix: Busines report will now work properly on first try. (It paid out a little too much :))


Version 0.6 Beta (10.07.2020):
- BugFix: Will require LP >= 3.0 to run
- BugFix: Some condition checks in do_shooting_new fixed

Version 0.5 Beta (09.02.2020):
- Added: Vima's Porn studio in 3 variants
- Added: Each porn studio variant is used depending on your scene equipment.
- Changed: You get a porn studio if you have a spacious, large or very large office.
- Changed: The larger the office is, the better the porn studio can be.
- Changed: Requires LifePlay 2.18 now
- Fixed: Male/Female selection in PornAgency Model selection not working
- Fixed: Performance of Inventory, Upload and random scenes improved. 
- Known: Business report is still slow to open as I did not modify it yet.

Version 0.2 Beta (29.01.2020):
- Change: Changed the "open porn empire" scene. Henk from PornAgency will now introduce himself and the game. If you want to see it again, close and reopen your company. (You will keep all your stuff.)
- Change: If the PornAgency searches a model for you, this person will no longer be an agency model (means you can negotiate on the price)
- Change: Gay footage is now produced if >= 1 male actor (and no female) takes part in a shooting. 
- Change: Did some text changes, added hints. Reworked the read me.
- Change: A larger office now allows to store more scene equipment. You cannot move to a smaller office if you have too much scene equipment.
- Change: Models won't get pregnant during shoots. They all use condoms and birth control pills...
- Added: 10 male PornAgency models
- Added: If you are low on money you can ask your relatives and dates to do a shooting for free. If their rapport with you is >= 55% they will do it.
- Added: GangBang and Reverse Gang Bang is now counted correctly in the model statistics (only shootings done with Version >= 0.2)
- Added: LifePlay version check to nn_pe_scene_start_porn_empire.lpscene - You need at least LifePlay 2.17 to play PE.
- BugFix: Equipment store now uses local currency. Lazy NickNo added the conversion now :-)
- BugFix: You can leave the toy store without buying anything
- BugFix: You can not ask the cam operator and scene assistant to be the main actor anymore
- BugFix: NPCs that agreed to model did not get the "PEModel" tag, and their shootings were not counted correctly
- BugFix: 1 male and 2 females were not detected as "Threesome".
- BugFix: Sometimes the PornAgency models did not cost money. This is due to a bug I cannot fix. (They sometimes get added with 0 pornfame, although I set one...)

Version 0.1 Beta (21.01.2020):
- Model agency added with 20 female high class models
- Model agency can be hired to search for new models with customized character generator
- Amateur, solo, 1-on-1, threesome and gang-bang as well as lesbian and gay shootings added (will be auto detected as soon as you do a shooting)
- Scene Assistant and cam operator can now join after a shooting (if enough space)
- Interest in amateur, solo, lesbian and gay gang bang stuff increases with growing number of uploaded content
- If the interest is not satisfied visitors will leave. So keep at least 3/4 of interest high!
- Model statistics added (see manage employees menu) -> Only work for new shootings
- Inventory added (see manage business menu) -> Only works for shootings Beta 0.1 and up!
- Web cam models can be fired now
- Web cam model training respects incest settings now
- Incest enabled if vin_Incest module is active
- Perversion and arousal are used now (perversion >55 makes contacts become models, arousal >65 triggers after work sex)
- Included Vima's hotel room preset

Internal fixes:
- Shooting scene reworked
- AllModelsAreBi setting works now

Version 0.05 Alpha (13.01.2020):
- Settings menu reworked
- Manage business menu added
- Game now respects models sexual interest (gender)
- Player can't do 1-on-1 shootings with relatives any more (but with other models and relatives)
- You can now select a location before doing a shooting (hotel, bed room, office, ...)
- Added one office and 3 hotel room presets
- You can now rent an office to store more equipment and do shootings in it
- Added "the PornAgency" for hiring models (costs more, agency boss etc.)

Version 0.04 Alpha (10.01.2020):
- You can watch and join cam shows
- Web cam models and employees will ask for salary increases randomly
- Random job applications as web cam model with random generated actors
- You can now book advertising campaigns in addition to the existing monthly advertising contracts
- Player and photographer will get horny (perverted) if they only have a passive role in a shooting
- If you are horny (perverted) enough you can join your models after shootings for some private fun
- If your photographer is horny (perverted) enough he/she can join after a 1-on-1 shooting with the player
- Job trainings added, can only be done once a week per employee
- Salary negotiations can only be done once a month
- Web camming now uses correct timing (weekly)
- Web camming balance algorithms reworked
- Scenes to hire and manage employees were consolidated and refactored, so they can be used for any employee type
- You can now hire scene assistants and cam operators (both for video shootings)
- Advertising menu reworked and uses new timing methods
- Debug menu extended
-> If you played a previous ALPHA version you may want to use the debug menu to DELTE ALL SETS...

Version 0.03 Alpha (04.01.2020):
- Business report now works with correct timing. You can trigger the action only once a day. The report will summarize if more then one day elapsed.
- You will loose visitors if you have only old photo sets on your website
- Management of employees added 
- Added photographer, the higher his/her porn fame is, the better shootings will be promoted
- Added web administrator. The admin will upload new stuff automatically. The higher his/her intelligence is, the better shootings will be made.
- Added staff training option
- Joining shootings is no more possible without having a photographer (you cant take perfect photos while fucking - right?)
- Bug fixed that prevented actions from triggering although you clicked them
- Actions now have energy conditions (if your energy is too low you cannot start them)
- Some actions now need to be trigged at a certain daytime (eg. doing shoots from 8AM till night)

Version 0.02 Alpha (02.01.2020):
- Added web cams incl. management of models
- Shootings + camming now costs money (sex workers get less)
- Changed the way visitors come to your website (no more random)
- Option to ask contacts to join shootings
- Option to add agency models to your contacts after first shooting
- Changed the way you buy equipment (step by step)
- Added more random dialogue items
- Reworked the algorithms in the business report (income calculations)

Version 0.01 Alpha (31.12.2019):
- Initial release


TODOs (Planned features by NickNo)
************************************
Developer
- nn_pe_scene_check_mail.lpscene -> Position the actors better! (If Vin adds a function to do so.)
- nn_pe_scene_check_mail.lpscene -> Add poses if Vin adds some...
- Add "VR Porn" as new type that can only be done with correct equipment


PRIO 1

PRIO 2
- Add Quests


PRIO 3
- Add some sort of competitors
- Add "Merchandise" to equipment
- Add events that massively increase / decrease visitor count
- ACTION: Allow player to adjust pe_PhotoSetPrice (fixed at 2,5$) and pe_WebCamShowPrice (5$)
  -> Reduce visitor count if requested price is too high for model & site fame

Feature Requests (Requested by others)
****************************************

LifePlay Patrons will be served first!

REQEST: Example request
FROM: NickNo (Discord)


Developer & Tester Notes
**************************

To open the debug menu press the # key and type:
nn_pe_debug + return
